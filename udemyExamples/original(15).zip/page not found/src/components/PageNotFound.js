import React from 'react'

const PageNotFound = () => {
    return (
        <div>
                <div className="container">
            <h4 className="center">Page Not Found</h4>
           
        </div>
        </div>
    )
}

export default PageNotFound
